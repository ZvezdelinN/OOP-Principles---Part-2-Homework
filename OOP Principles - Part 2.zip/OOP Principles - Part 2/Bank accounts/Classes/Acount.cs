﻿namespace Bank_accounts.Classes
{
    using System;
    using System.Collections;

    public abstract class Account 
    {
        private string firstName;
        private string lastName;
        private string companyName;
        private double interestRate;
        private int monthOfTheAccount;

        public Account(string custemerFirsName, string custemerLastName, double custemerBallance, double custemerInterestRate, int monthsOfAccount)
        {
            this.FirstName = custemerFirsName;
            this.LastName = custemerLastName;
            this.Ballance = custemerBallance;
            this.interestRate = custemerInterestRate;
            this.monthOfTheAccount = monthsOfAccount;
            this.IsCompany = false;
        }

        public Account(string custemerCompanyName, double custemerBallance, double custemerInterestRate, int monthsOfAccount)
        {
            this.CompanyName = custemerCompanyName;
            this.Ballance = custemerBallance;
            this.interestRate = custemerInterestRate;
            this.monthOfTheAccount = monthsOfAccount;
            this.IsCompany = true;
        }

        public string FirstName
        {
            get
            {
                return this.firstName;
            }

            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The length of the first name couldn't be null or empty!");
                }

                this.firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return this.lastName;
            }

            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The length of the first name couldn't be null or empty!");
                }

                this.lastName = value;
            }
        }

        public string CompanyName
        {
            get
            {
                return this.companyName;
            }

            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The length of the first name couldn't be null or empty!");
                }

                this.companyName = value;
            }
        }

        public double InterestRate
        {
            get
            {
                return this.interestRate;
            }

            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("The value of the interest couldn't be a negative number");
                }

                this.interestRate = value;
            }
        }

        public int MonthsOfTheAccount
        {
            get
            {
                return this.monthOfTheAccount;
            }

            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("The number of the months couldn't be negative!");
                }

                this.monthOfTheAccount = value;
            }
        }

        public double Ballance { get; set; }

        public bool IsCompany { get; set; }
        
        public abstract void CalculateRate(int month, double rate);

        public abstract void Deposite(double value);
    }
}

﻿namespace Bank_accounts.Classes
{
    using System;

    public class Loan : Account
    {
        public Loan(string custemerFirsName, string custemerLastName, double custemerBallance, double custemerInterestRate, int monthsOfAccount)
            : base(custemerFirsName, custemerLastName, custemerBallance, custemerInterestRate, monthsOfAccount)
        {
        }

        public Loan(string custemerCompanyName, double custemerBallance, double custemerInterestRate, int monthsOfAccount)
            : base(custemerCompanyName, custemerBallance, custemerInterestRate, monthsOfAccount)
        {
        }

        public override void CalculateRate(int month, double rate)
        {
            if (this.IsCompany && this.MonthsOfTheAccount <= 2)
            {
                this.MonthsOfTheAccount = month;
                return;
            }
            else if (!this.IsCompany && this.MonthsOfTheAccount <= 3)
            {
                this.MonthsOfTheAccount += month;
                return;
            }
            else
            {
                this.MonthsOfTheAccount += month;
                this.Ballance += month * rate;
                Console.WriteLine(this.Ballance);
            }
        }

        public override void Deposite(double value)
        {
            this.Ballance += value;
            Console.WriteLine(this.Ballance);
        }

        public override string ToString()
        {
            if (this.IsCompany)
            {
                return string.Format("The \"{0}\" has ballance : {1}, it's interest is : {2} and the account is from {3} months.", this.CompanyName, this.Ballance, this.InterestRate, this.MonthsOfTheAccount);
            }
            else
            {
                return string.Format("{0} {1} has ballance : {2}, it's interest is : {3} and the account is from {4} months.", this.FirstName, this.LastName, this.Ballance, this.InterestRate, this.MonthsOfTheAccount);
            }
        }
    }
}

﻿namespace Bank_accounts.Classes
{
    using System;

    public class Deposit : Account
    {
        public Deposit(string custemerFirsName, string custemerLastName, double custemerBallance, double custemerInterestRate, int monthsOfAccount) 
            : base(custemerFirsName, custemerLastName, custemerBallance, custemerInterestRate, monthsOfAccount)
        {
        }

        public Deposit(string custemerCompanyName, double custemerBallance, double custemerInterestRate, int monthsOfAccount)
            : base(custemerCompanyName, custemerBallance, custemerInterestRate, monthsOfAccount)
        {
        }

        public override void CalculateRate(int month, double rate)
        {
            if ((this.Ballance < 0 ) || (this.Ballance > 0 && this.Ballance < 1000))
            {
                this.MonthsOfTheAccount += month;
                return;
            }

            this.MonthsOfTheAccount += month;
            this.Ballance += month * rate;
        }

        public override void Deposite(double value)
        {
            this.Ballance += value;
        }

        public void WithDraw(double sum)
        {
            this.Ballance -= sum;
        }

        public override string ToString()
        {
            if (this.IsCompany)
            {
               return string.Format("The \"{0}\" has ballance : {1}, it's interest is : {2} and the account is from {3} months.", this.CompanyName, this.Ballance, this.InterestRate, this.MonthsOfTheAccount);
            }
            else
            {
                return string.Format("{0} {1} has ballance : {2}, it's interest is : {3} and the account is from {4} months.", this.FirstName, this.LastName, this.Ballance, this.InterestRate, this.MonthsOfTheAccount);
            }
        }
    }
}

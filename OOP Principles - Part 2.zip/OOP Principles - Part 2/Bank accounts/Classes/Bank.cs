﻿namespace Bank_accounts.Classes
{
    using System;
    using System.Collections.Generic;

    public class Bank
    {
        public Bank()
        {
            this.AccountList = new List<Account>(); 
        }

        public List<Account> AccountList { get; set; }
    }
}

﻿namespace Bank_accounts
{
    using System;
    using Bank_accounts.Classes;

    public class Start
    {
        public static void Main(string[] args)
        {
            Bank newBank = new Bank();

            Deposit firstDeposit = new Deposit("My firm OOD", 0, 0.75, 0);
            Deposit secondDeposit = new Deposit("Zvezdelin", "Nikolaev", 0, 0.75, 0);
            Loan firstLoan = new Loan("Monsters Incorporated", 0, 0.75, 0);
            Loan secondLoan = new Loan("Petar", "Ananstasov", 0, 0.75, 0);
            Mortgage firstMortgage = new Mortgage("Telerik Academy", 0, 0.75, 0);
            Mortgage secondMorgage = new Mortgage("Dimitar", "Chucharkov", 0, 0.75, 0);

            newBank.AccountList.Add(firstDeposit);
            newBank.AccountList.Add(secondDeposit);
            newBank.AccountList.Add(firstLoan);
            newBank.AccountList.Add(secondLoan);
            newBank.AccountList.Add(firstMortgage);
            newBank.AccountList.Add(secondMorgage);

            for (int i = 0; i < newBank.AccountList.Count; i++)
            {
                Console.WriteLine(i + " " + newBank.AccountList[i]);
            }

            Console.WriteLine();

            firstDeposit.Deposite(100);
            firstDeposit.CalculateRate(5, 0.75);
            Console.WriteLine(firstDeposit);

            Console.WriteLine();

            firstDeposit.Deposite(1000);
            firstDeposit.CalculateRate(5, 0.75);
            Console.WriteLine(firstDeposit);

            Console.WriteLine();

            firstDeposit.WithDraw(150);
            Console.WriteLine(firstDeposit);
            
        }
    }
}

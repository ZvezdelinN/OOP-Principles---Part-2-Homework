﻿namespace Range_Exceptions
{
    using System;

    public class Start
    {
        public static void Main()
        {
            Console.Write("Enter a number : ");
            int aNumber = int.Parse(Console.ReadLine());
            CheckNumber(aNumber);
        }

        public static void CheckNumber(int number)
        {
            try
            {
                if (number < 1 || number > 100)
                {
                    throw new InvalidRangeException("The given number is out of range");
                }

                Console.WriteLine("The number {0} is OK.", number);
                return;
            }
            catch (InvalidRangeException ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}

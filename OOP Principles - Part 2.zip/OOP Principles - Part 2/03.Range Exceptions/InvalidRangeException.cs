﻿namespace Range_Exceptions
{
    using System;

    public class InvalidRangeException : ApplicationException
    {
        public InvalidRangeException(string message) 
            : base(message)
        {
        }

        public InvalidRangeException(string message, Exception innerExcept)
            : base(message, innerExcept)
        {
        }
    }
}

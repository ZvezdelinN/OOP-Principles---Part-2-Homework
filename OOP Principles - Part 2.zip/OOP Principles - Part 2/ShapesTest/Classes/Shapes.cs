﻿namespace ShapesTest.Classes
{
    using System;

    public abstract class Shapes
    {
        private int height;

        private int width;

        public Shapes(int enterHeight, int enterWidth)
        {
            this.Height = enterHeight;
            this.Width = enterWidth;
        }
        
        public int Height
        {
            get
            {
                return this.height;
            }

            set
            {
                if (value < 0)
                {
                    throw new IndexOutOfRangeException("The height couldn't be negative");
                }

                this.height = value; 
            }
        }

        public int Width
        {
            get
            {
                return this.width;
            }

            set
            {
                if (value < 0)
                {
                    throw new IndexOutOfRangeException("The height couldn't be negative");
                }

                this.width = value;
            }
        }

        public abstract double CalculateSurface(int shapeHeight, int shapeWidth);
    }
}

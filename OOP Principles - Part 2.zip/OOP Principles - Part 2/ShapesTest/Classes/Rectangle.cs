﻿namespace ShapesTest.Classes
{
    using System;

    public class Rectangle : Shapes
    {
        public Rectangle(int recHeight, int recWidth) : base(recHeight, recWidth)
        {
        }

        public override double CalculateSurface(int rectangleHeight, int rectangleWidth)
        {
            return rectangleHeight * rectangleWidth;
        }
    }
}

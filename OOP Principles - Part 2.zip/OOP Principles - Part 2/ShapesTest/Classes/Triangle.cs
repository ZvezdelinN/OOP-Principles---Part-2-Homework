﻿namespace ShapesTest.Classes
{
    using System;

    public class Triangle : Shapes
    {
        public Triangle(int triangleHeight, int triangleWidth) : base(triangleHeight, triangleWidth)
        {
        }

        public override double CalculateSurface(int triHeigh, int triWidth)
        {
            return (triHeigh * triWidth) / 2;
        }
    }
}

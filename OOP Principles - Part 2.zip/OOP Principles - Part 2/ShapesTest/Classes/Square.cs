﻿namespace ShapesTest.Classes
{
    using System;

    public class Square : Shapes
    {
        public Square(int side) : base(side, side)
        {
        }

        public override double CalculateSurface(int squareSide1, int squareSide2)
        {
            return squareSide1 * squareSide2;
        }
    }
}

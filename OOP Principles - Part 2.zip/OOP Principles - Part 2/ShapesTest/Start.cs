﻿namespace ShapesTest
{
    using System;
    using ShapesTest.Classes;
    using System.Collections.Generic;

    class Start
    {
        static void Main()
        {
            var triangle = new Triangle(12, 12);
            double triangleResult = triangle.CalculateSurface(triangle.Height,triangle.Width);
            //Console.WriteLine(triangleResult);

            var rectangle = new Rectangle(12, 13);
            double rectangleResult = rectangle.CalculateSurface(rectangle.Height, rectangle.Width);  
            //Console.WriteLine(rectangleResult);

            var square = new Square(15);
            double squareResult = square.CalculateSurface(rectangle.Height, rectangle.Width);
            //Console.WriteLine(squareResult);

            List<Shapes> figures = new List<Shapes>();
            figures.Add(square);
            figures.Add(rectangle);
            figures.Add(triangle);

            foreach(Shapes figure in figures)
            {
                double result = figure.CalculateSurface(figure.Height, figure.Height);
                Console.WriteLine("The surface of the {0} is : {1}",figure.GetType().Name,result);
            }

        }
    }
}
